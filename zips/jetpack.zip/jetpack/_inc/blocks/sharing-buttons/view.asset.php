<?php return array('dependencies' => array('wp-dom-ready'), 'version' => '2f5b08f8fcbda634bcde');
