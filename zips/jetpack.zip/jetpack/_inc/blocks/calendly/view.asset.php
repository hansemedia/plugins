<?php return array('dependencies' => array(), 'version' => '2c6dcab855ebf648b7a9');
