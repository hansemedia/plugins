<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'e6bdbc871155eb08c519');
