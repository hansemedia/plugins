<?php return array('dependencies' => array(), 'version' => '5231dd3e4c3538cac476');
