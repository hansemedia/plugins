<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => '96639808cf6a5b0339ee');
