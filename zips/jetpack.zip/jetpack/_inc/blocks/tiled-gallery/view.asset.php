<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'f0571a42d7c9277d6946');
