<?php return array('dependencies' => array(), 'version' => '966dd642fdcc7ec34770');
