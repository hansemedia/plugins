<?php return array('dependencies' => array(), 'version' => '6b7eb23ded175447060f');
