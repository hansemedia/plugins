<?php return array('dependencies' => array('wp-polyfill'), 'version' => '0d4bc8846ef7f6286b82');
