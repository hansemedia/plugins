<?php return array('dependencies' => array('wp-dom-ready', 'wp-polyfill'), 'version' => 'b5c74382e2eac6edaa25');
