<?php return array('dependencies' => array(), 'version' => '93b614c160c025193e3f');
