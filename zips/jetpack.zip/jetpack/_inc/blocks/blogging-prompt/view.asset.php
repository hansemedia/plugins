<?php return array('dependencies' => array(), 'version' => '5182e0629d0214a32263');
