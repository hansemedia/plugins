<?php return array('dependencies' => array(), 'version' => 'eac6f0b5fc3e121e5481');
