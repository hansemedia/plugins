<?php return array('dependencies' => array(), 'version' => '4f6c55862658b54769e5');
