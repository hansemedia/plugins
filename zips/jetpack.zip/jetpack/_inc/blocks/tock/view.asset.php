<?php return array('dependencies' => array(), 'version' => '55855df5982d726811a3');
