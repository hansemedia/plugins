<?php return array('dependencies' => array(), 'version' => 'bdb414b13f4a2554f52b');
