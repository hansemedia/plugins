<?php return array('dependencies' => array('lodash', 'moment', 'wp-i18n'), 'version' => '1b12f84916de483ca5c2');
