<?php

namespace WPForms\Admin\Forms\Table\DataObjects;

use WPForms\Admin\Base\Tables\DataObjects\ColumnBase;

/**
 * Column data object.
 *
 * @since 1.8.6
 */
class Column extends ColumnBase {}
