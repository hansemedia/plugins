import Onboarding from "../Onboarding/Onboarding";

const Activate = () => {
    return (
        <div className="rsssl-lets-encrypt-tests">
            <Onboarding/>
         </div>
    )
}

export default Activate;