<?php
namespace Elementor\Core\Experiments\Exceptions;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

class Dependency_Exception extends \Exception {
}
