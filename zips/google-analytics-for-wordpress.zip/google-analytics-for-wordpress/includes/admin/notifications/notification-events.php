<?php

$base = MonsterInsights();
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-install-user-feedback.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-visitors.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-audience.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-mobile-device-high-traffic.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-mobile-device-low-traffic.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-upgrade-to-pro.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-upgrade-to-pro-high-traffic.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-bounce-rate.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-returning-visitors.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-traffic-dropping.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-upgrade-for-post-templates.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-upgrade-for-events-reporting.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-upgrade-for-search-console.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-upgrade-for-form-conversion.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-upgrade-for-email-summaries.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-upgrade-for-custom-dimensions.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-upgrade-eu-traffic.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-to-add-more-file-extensions.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-to-setup-affiliate-links.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-headline-analyzer.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-install-optinmonster.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-install-aioseo.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-install-wp-forms.php';
require_once plugin_dir_path( $base->file ) . '/includes/admin/notifications/notification-multiple-gtags.php';
