<?php

define( 'REDIRECTION_VERSION', '5.5.1' );
define( 'REDIRECTION_MIN_WP', '6.4' );
define( 'REDIRECTION_BUILD', '08d49200baf486dd62bdff53420d0b5d' );
